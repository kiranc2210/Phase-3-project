INSERT INTO sportyshoes.admin_tbl VALUES(1001,"Admin_1001",61162433);

SELECT * FROM sportyshoes.admin_tbl;

